public class Curso {
  public String nome;
  public int duracao;
  public int alunos;
  public char turno;

}
