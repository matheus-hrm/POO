public class instanceMethod {
  private int x;

  public instanceMethod(int value) {
    this.x = value;
  }
}
/*  Métodos de instância são associados a uma instância específica de uma classe.
    Devem ser invocados através de uma instância da classe utilizando o operador ponto.
    Métodos de instância podem acessar atributos de instância e métodos de instância.
 */