public class staticMethod {
  private static int x;
  
  public static void contador() {
    x++;
  }
}

/* Métodos estáticos são associados a própria classe e não tem acesso aos atributos de instância da classe 
   Podem ser invocados diretamente na classe sem necessidade de instância.
 * 
 */

